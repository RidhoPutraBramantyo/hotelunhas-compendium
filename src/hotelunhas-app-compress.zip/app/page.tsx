import Image from "next/image";
import { Oranienbaum, Poppins } from "next/font/google";
import { Button } from "@/components/ui/button";
import Carousel from "@/components/ui/carousel";

const oranienbaum = Oranienbaum({
  weight: "400",
  subsets: ["latin"],
});

const poppins = Poppins({
  weight: "400",
  subsets: ["latin"],
});

const carouselItem = [
  {
    imgSrc: "",
    title: "Deluxe Room",
    desc: "The room is quite spacious and elegantly designed, this room is 34.7 square meters with high speed WIFI ...",
    readMoreLink: "/",
    buttonLink: "/room",
  },
  {
    imgSrc: "",
    title: "Junior Suite Room",
    desc: "The room is quite spacious and elegantly designed, this room covers an area of 43.8 square....",
    readMoreLink: "",
    buttonLink: "/room",
  },
  {
    imgSrc: "",
    title: "Executive Suite Room",
    desc: "A very spacious room consisting of a separate bedroom and living room with room dimensions of 54.3....",
    readMoreLink: "",
    buttonLink: "/room",
  },
  {
    imgSrc: "",
    title: "Presidential Suite Room",
    desc: "The very spacious room consists of a separate bedroom and living room with room dimensions of 80.8....",
    readMoreLink: "",
    buttonLink: "/room",
  },
];

const rooms = [
  {
    imageUrl:
      "https://hotelunhas.com/wp-content/uploads/2024/06/Group-Deluxe-Room.png",
    title: "Deluxe Room",
    description:
      "The room is quite spacious and elegantly designed, this room is 34.7 square meters with high speed WIFI",
    readMoreLink: "#",
  },
  {
    imageUrl:
      "https://hotelunhas.com/wp-content/uploads/2024/06/Group-Deluxe-Room.png",
    title: "Deluxe Room",
    description:
      "The room is quite spacious and elegantly designed, this room is 34.7 square meters with high speed WIFI",
    readMoreLink: "#",
  },
  {
    imageUrl:
      "https://hotelunhas.com/wp-content/uploads/2024/06/Group-Deluxe-Room.png",
    title: "Deluxe Room",
    description:
      "The room is quite spacious and elegantly designed, this room is 34.7 square meters with high speed WIFI",
    readMoreLink: "#",
  },
  {
    imageUrl:
      "https://hotelunhas.com/wp-content/uploads/2024/06/Group-Deluxe-Room.png",
    title: "Deluxe Room",
    description:
      "The room is quite spacious and elegantly designed, this room is 34.7 square meters with high speed WIFI",
    readMoreLink: "#",
  },
  {
    imageUrl:
      "https://hotelunhas.com/wp-content/uploads/2024/06/Group-Deluxe-Room.png",
    title: "Deluxe Room",
    description:
      "The room is quite spacious and elegantly designed, this room is 34.7 square meters with high speed WIFI",
    readMoreLink: "#",
  },
  // Tambahkan lebih banyak data sesuai kebutuhan
];

export default function Home() {
  return (
    <div className="w-full flex flex-col items-center text-black">
      <section className="w-full pb-5">
        <iframe
          src="https://www.youtube.com/embed/t9zYp2jMdIE?start=11&autoplay=1&controls=0&modestbranding=1&rel=0"
          className="w-full h-screen"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
        ></iframe>
      </section>
      <section
        className={`flex flex-col w-full items-center gap-4 ${poppins.className} bg-primary px-10 py-5`}
      >
        <h1 className={`${oranienbaum.className} text-5xl`}>
          Welcome to Unhas Hotel & Convention
        </h1>
        <h3 className="font-semibold text-xl">Harmonizing and Comfort</h3>
        <p className="text-center">
          Located within a sprawling 223.9-hectare campus, Unhas Hotel &amp;
          Convention.
        </p>
        <p className="text-center ">
          Surrounded by lush greenery, our hotel provides a tranquil and
          peaceful atmosphere, perfect for unwinding after a busy day. Every
          corner of the hotel is designed with elegant touches, ensuring comfort
          and visual appeal for our guests. We are committed to making every
          visit a special and memorable experience, whether for business or
          leisure.
        </p>
      </section>
      <section
        className={`flex flex-col w-full items-center gap-4 ${poppins.className} bg-white px-10 py-5`}
      >
        <h1 className={`${oranienbaum.className} text-5xl`}>Accomodation</h1>
        <div className="flex w-full justify-center gap-4">
          <Carousel />
        </div>
      </section>

      <section
        className={`flex flex-col w-full items-center gap-4 ${poppins.className} bg-primary px-10 py-5`}
      >
        <h1 className={`${oranienbaum.className} text-5xl`}>Amenities</h1>
        <h3 className="font-semibold text-xl ">
          Book now and experience exceptional comfort with our premium
          amenities. Enjoy a luxurious and unforgettable stay.
        </h3>

        <div className="flex flex-wrap justify-center items-center gap-5">
          {[
            "Free parking",
            "Business Center with Internet Access",
            "Parking",
            "Restaurant",
            "Breakfast buffet",
            "Tennis court",
            "Meeting rooms",
            "BBQ facilities",
            "24-hour front desk",
            "Private check-in/check-out",
            "Laundry service",
            "Free High Speed Internet",
            "Gymnasium",
          ].map((item, index) => (
            <div
              key={index}
              className="text-sm text-gray-800 border border-black rounded-full py-1 px-5 bg-[#fffbe8]"
            >
              {item}
            </div>
          ))}
        </div>
      </section>
      <section
        className={`flex flex-col w-full items-center gap-4 ${poppins.className} bg-secondary px-10 py-5`}
      >
        <h1 className={`${oranienbaum.className} text-5xl`}>Promo Event</h1>
        <div> disini carousel poster</div>{" "}
      </section>
      <section className={`w-full py-5 bg-black`}>
        <div className="w-full ">
          <iframe
            src="https://www.youtube.com/embed/avWdI4r0sv0?start=11&autoplay=1&mute=1&controls=0&modestbranding=1&rel=0"
            className="w-full h-screen"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          ></iframe>
        </div>
      </section>

      <section
        className={`flex flex-col w-full items-center gap-4 ${poppins.className} bg-primary px-10 py-5`}
      >
        <h1 className={`${oranienbaum.className} text-9xl`}>“</h1>
        {/* <div className="flex justify-center w-full">
          <CarouselSize />
        </div> */}
      </section>
    </div>
  );
}
